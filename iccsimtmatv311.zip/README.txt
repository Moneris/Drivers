---------------------
- ICCSimTMat v3.1.1 -
---------------------


Documentation
-------------

Documentation will be installed into C:\ICCSim50\Documentation


New Installation
----------------

Installation directions are in ICCsimat in the ICC Guide 2010.02.pdf file

1. Run Moneris Enviroment.exe in ICCSimat directory
2. Run setup.exe in the ICCsimat directory
3. Run setup.exe in SDI010 Drivers and Firmware\SDI010_installer_V1.04 to install drivers for the reader writer


Upgrade installation
--------------------

Uninstall ICCsimTMat from add/remove programs in control panel
Rename or remove the current c:\iccsim50 directory

Run steps 1 & 2 from New Installation above


Support
-------

For technical assisstance call 1-800-769-8358

Thank you,
Moneris Solutions