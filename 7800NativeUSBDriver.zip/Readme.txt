The files in this zip package are a fully released version of the new V5.3.0 VCOM driver which supports Vista, XP and Win2k.

This release contains the following components:

* x64 directory
	* silabser.sys
	* silabenm.sys
* x86 directory
	* silabser.sys
	* silabenm.sys
* CP210xVCPInstaller.exe (v2.4)
* setup.ini
* ingvcp.cat
* ingvcp.inf
* Readme.txt (this file)

The files in the zip package should be extracted to a temporary directory on the host preserving the paths included. Then the CP210xVCPInstaller.exe should be run to perform the install.

Any older VCOM drivers will be deleted and replaced.
